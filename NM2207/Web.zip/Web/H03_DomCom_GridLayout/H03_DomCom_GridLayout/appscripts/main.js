// main.js

console.log(`yo`);

//styling article element
document.getElementById("articlecontent").style.fontFamily = "Garamond, serif";
document.getElementById("articlecontent").style.font = "italic 10px Garamond,serif";

//centering the header
document.getElementById("header").style.textAlign = "center";